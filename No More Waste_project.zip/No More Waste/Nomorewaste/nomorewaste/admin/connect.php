<?php
session_start();

include '../connection.php'; // Make sure this file sets up the $connection variable properly

$msg = 0;

if (isset($_POST['sign'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize the input to prevent SQL injection
    $sanitized_emailid = mysqli_real_escape_string($connection, $email);
    $sanitized_password = mysqli_real_escape_string($connection, $password);

    // Query to select user details based on the provided email
    $sql = "SELECT * FROM admin WHERE email = '$sanitized_emailid'";
    $result = mysqli_query($connection, $sql);

    if ($result) {
        $num = mysqli_num_rows($result);

        if ($num == 1) {
            $row = mysqli_fetch_assoc($result);

            // Verify the password
            if (password_verify($sanitized_password, $row['password'])) {
                // Set session variables
                $_SESSION['email'] = $email;
                $_SESSION['name'] = $row['name'];
                $_SESSION['location'] = $row['location'];
                $_SESSION['Aid'] = $row['Aid'];

                // Redirect to admin dashboard
                header("location:admin.php");
                exit();
            } else {
                $msg = 1; // Incorrect password
            }
        } else {
            echo "<h1><center>Account does not exist</center></h1>";
        }
    } else {
        echo "<h1><center>Error executing query: " . mysqli_error($connection) . "</center></h1>";
    }
}
?>
